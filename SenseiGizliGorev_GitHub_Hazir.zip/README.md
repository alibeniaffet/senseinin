# 🥷 Sensei: Gizli Görev

Android APK olarak derlenebilen Sensei temalı online sosyal çıkarım oyunu prototipi.

## GitHub'a yükleme
Bu klasörün tamamını repository'ye yükle.

## APK
GitHub > Actions > Build Android APK > Run workflow.
Derleme sonunda **Artifacts** bölümünden `Sensei-Gizli-Gorev-APK` dosyasını indir.

## Kendi online backend'in
`app/` içine daha sonra Firebase yapılandırma dosyanı (`google-services.json`) koyabilirsin.
Kodda online servis bağlantısını daha sonra Firebase/WebSocket backend'in ile değiştirebilirsin.

Bu sürüm internet izni ve online backend'e bağlanabilecek mimari başlangıç noktası içerir; backend olmadan demo oda sistemi çalışır.
